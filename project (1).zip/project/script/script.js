function validation(){
var x = document.getElementById("name").value;
var empt = (/ /.test(x));
if (empt == false){
document.getElementById("alert1").innerHTML = "Name is invalid"}

else if (empt == true){
document.getElementById("alert1").innerHTML = "Name is valid"}


var y=document.getElementById("email").value;
var result = (/@/.test(y));

if (result == false){
document.getElementById("alert2").innerHTML = "Email must be valid"}

else if (result == true){
document.getElementById("alert2").innerHTML = "Email is valid"}

var robot = document.getElementById("robo").value;
if (robot == 14){
document.getElementById("alert4").innerHTML="Information has been accepted";
}
else{
document.getElementById("alert4").innerHTML="Wrong, please try again!!";}

var z = document.getElementById("comment").value;
var empty = (/ /.test(z));
if (empty == false){
document.getElementById("alert3").innerHTML = "Comments is invalid, please input something!!"}

else if (empty == true){
document.getElementById("alert3").innerHTML = "Comments is valid"}

if(empty==true && empt==true && result==true && robot==14){
document.getElementById('contact').style.display="none";
document.getElementById('show2').style.display="block";
document.getElementById('text').style.display="none";
}

}



/*Invalid */
var invalidClassName = 'invalid'
var inputs = document.querySelectorAll('input, select, textarea')
inputs.forEach(function (input) {
  // Add a css class on submit when the input is invalid.
  input.addEventListener('invalid', function () {
    input.classList.add(invalidClassName)
  })

  // Remove the class when the input becomes valid.
  // 'input' will fire each time the user types
  input.addEventListener('input', function () {
    if (input.validity.valid) {
      input.classList.remove(invalidClassName)
    }
  })
})


/*Button Toggle */


    
    
    
  