var express = require("express"); // Call the express module which is default provded by Node
var app = express(); // Now we need to declare our app which is the envoked express application
var mysql= require('mysql');//Allows access to SQL

var bodyParser = require("body-parser");
app.use(bodyParser.urlencoded({extended: true}));

app.set('view engine', 'ejs');

const fileUpload = require('express-fileupload');
app.use(fileUpload());


//This makes the file look in the various folders

app.use(express.static("views"));
app.use(express.static("script"));
app.use(express.static("images"));
//app.use(express.static("model"));




//*************************** SQL Connection Details **********************//

const db = mysql.createConnection({

  

});



db.connect((err) =>{
    if(err){
        console.log("Connection Refused");
       
    }
    else{
        console.log("Well done you are connected....");
    }
});



//*************************** END SQL Connection Details **********************//

//**************UPLOADER******************//

app.get("/upload", function(req, res){
  
    res.render("upload.ejs")
    console.log("On upload page")
    
});




app.post('/upload', function(req, res) {
  if (!req.files)
    return res.status(400).send('No files were uploaded.');
 
  // The name of the input field (i.e. "sampleFile") is used to retrieve the uploaded file
  let sampleFile = req.files.sampleFile;
  
  
  let filename = sampleFile.name;
  // Use the mv() method to place the file somewhere on your server
  sampleFile.mv('./images/' + filename, function(err) {
    if (err)
      return res.status(500).send(err);
 console.log("Here is the image " + req.files.sampleFile)
    res.redirect('/');
  });
});




//***************END UPLOADER **********//




 /*Get Products */
app.get('/products',  function(req, res){  
 let sql = 'SELECT * FROM products'
  let query = db.query(sql, (err, res1) => {
    if(err) throw err;
    console.log(res1);

    res.render('products', {res1});
  });
 
  console.log("Now you are on the products page!");
});

app.get('/', function(req, res) {
res.render("index.ejs") 
console.log("Hello World"); // Used to output activity in the console
});


app.get("/contacts", function(req, res){
    
   
    res.render("contact.ejs")
    console.log("On contact page!")
    
});
app.get("/aboutus", function(req, res){
    
   
    res.render("aboutus.ejs")
    console.log("On about us page!")
    
});
  
app.get('/staff',  function(req, res){  
 let sql = 'SELECT * FROM staff'
  let query = db.query(sql, (err, res2) => {
    if(err) throw err;
    console.log(res2);

    res.render('staff', {res2});
  });
 
  console.log("Now you are on the products page!");
});


//Get the addstaff page to load
app.get('/addstaff', function(req, res) {
res.render("addStaff.ejs") 
console.log("Add-Staff working"); 
});

app.get('/thankyou', function(req, res) {
res.render("thankyou.ejs") 
console.log("Thank you working"); 
});




  
//Get the addproducts page to load
app.get('/addproducts', function(req, res) {
res.render("addproduct.ejs") 
console.log("Add-Products working"); 
});



app.get('/create', function(req, res) {
  let sql = 'CREATE TABLE products ( Id int NOT NULL AUTO_INCREMENT PRIMARY KEY, Name varchar(255), Price double, Image varchar(255),Supplier varchar(255));'
  let query = db.query(sql, (err, res) => {
    if(err) throw err;
    console.log(res);
    
    
  });
  res.send("Creating the table");
  });

app.get('/makeproduct', function(req, res) {
  let sql = 'INSERT INTO products(Name, Price, Image, Supplier) VALUES ("Brennans Bread", 1.49, "BrenannsBreadToday.png", "Brennans")';
  let query = db.query(sql, (err, res1) => {
    if(err) throw err;
    console.log(res);
    
    
  });
  res.send("Product Created...");
  });
  

 
 
  console.log("Now you are on the create products page!");

//End of function to create page



//Delete Product Function 
app.get('/delete/:id',  function(req, res){
    let sql = 'DELETE FROM Products WHERE Id = "'+req.params.id+'" ; ';
  let query = db.query(sql, (err, res1) => {
    if(err) throw err;
    console.log(res);
    
    res.redirect('/products'); 
  });
});



  
  
 

  app.post('/addproducts', function(req, res){
  let sql = 'INSERT INTO products (Name, Price, Image, Supplier) VALUES ("'+req.body.name+'", '+req.body.price+', "'+req.body.image+'", "'+req.body.supplier+'")'
  let query = db.query(sql, (err, res) => {
    if(err) throw err;
    console.log(res);
    
    
  });
  res.redirect("/products");
  });





/*Edit Product Button */
app.get('/edit/:id', function(req, res){
    let sql = 'SELECT * FROM Products WHERE Id = "'+req.params.id+'" ; ';
  let query = db.query(sql, (err, res1) => {
    if(err) throw err;
    console.log(res);
    
    res.render('edit', {res1}); 
  });
  
    
    console.log("Edit Worked");
    
});



app.post('/edit/:id', function(req, res){
  let sql = 'UPDATE products SET Name = "'+req.body.name+'", Price = "'+req.body.price+'", Image = "'+req.body.image+'", Supplier = "'+req.body.supplier+'" WHERE Id = "'+req.params.id+'";'
  let query = db.query(sql, (err, res) => {
    if(err) throw err;
    console.log(res);
    
    
  });
  res.redirect("/products");
  });

/*Show Button */
app.get('/show/:id', function(req, res){
    
    let sql = 'SELECT * FROM Products WHERE Id = "'+req.params.id+'" ; '
    let query = db.query(sql, (err, res1) => {
    if(err) throw err;
    console.log(res);
    
    res.render("show.ejs", {res1}) 
  });
  
    
    
    
    console.log("Show page worked");
});



/* ------------------STAFF SQL SECTION---------------------- */
app.get('/create2', function(req, res) {
  let sql = 'CREATE TABLE staff ( Id int NOT NULL AUTO_INCREMENT PRIMARY KEY, Name varchar(255), Title varchar(255), Image varchar(255), Salary DECIMAL(9,2));'
  let query = db.query(sql, (err, res) => {
    if(err) throw err;
    console.log(res);
    
    
  });
  res.send("Staff Table Created");
  });

//Initial Create for staff

app.get('/makestaff', function(req, res) {
  let sql = 'INSERT INTO staff(Name, Title, Image, Salary) VALUES ("Alex", "Manager", "man.jpg", "20000.00")';
  let query = db.query(sql, (err, res2) => {
    if(err) throw err;
    console.log(res);
    
    
  });
  res.send("Staff Created...");
  });

  
//Deleting a staff
app.get('/delete2/:id',  function(req, res){
    let sql = 'DELETE FROM staff WHERE Id = "'+req.params.id+'" ; ';
  let query = db.query(sql, (err, res1) => {
    if(err) throw err;
    console.log(res);
    
    res.redirect('/staff'); 
  });
});
    






//Add Staff 
  app.post('/addstaff', function(req, res){
  let sql = 'INSERT INTO staff (Name, Title, Image, Salary) VALUES ("'+req.body.name+'", "'+req.body.title+'", "'+req.body.image+'", "'+req.body.salary+'")'
  let query = db.query(sql, (err, res) => {
    if(err) throw err;
    console.log(res);
    
    
  });
  res.redirect("/staff");
  });

    
    
    
    
    
    
    
    
//Editing a staff member'
app.get('/edit2/:id', function(req, res){
    let sql = 'SELECT * FROM staff WHERE Id = "'+req.params.id+'" ; ';
  let query = db.query(sql, (err, res2) => {
    if(err) throw err;
    console.log(res);
    
    res.render('edit2', {res2}); 
  });

});



app.post('/edit2/:id', function(req, res){
  let sql = 'UPDATE staff SET Name = "'+req.body.name+'", Title = "'+req.body.title+'", Image = "'+req.body.image+'", Salary = "'+req.body.salary+'" WHERE Id = "'+req.params.id+'";'
  let query = db.query(sql, (err, res) => {
    if(err) throw err;
    console.log(res);
    
    
  });
  res.redirect("/staff");
  });


//Show Staff member
app.get('/show2/:id', function(req, res){
    
    let sql = 'SELECT * FROM staff WHERE Id = "'+req.params.id+'" ; '
    let query = db.query(sql, (err, res2) => {
    if(err) throw err;
    console.log(res);
    
    res.render("show2.ejs", {res2}) 
  });
  
    
    
    console.log("Show page worked");
});

    
    
    

// This code provides the server port for our application to run on
app.listen(process.env.PORT || 3000, process.env.IP || "0.0.0.0", function() {
console.log("It is now running");
  
});


  
    